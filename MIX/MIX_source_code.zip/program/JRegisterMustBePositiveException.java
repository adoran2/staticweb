//: JRegisterMustBePositiveException.java
//  An Exception thrown by JRegister

/** JRegisterMustBePositiveException is an Exception thrown by JRegister
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 March 1999
 *  @see JRegister
*/
class JRegisterMustBePositiveException extends CharNotASignException { }

///:~
