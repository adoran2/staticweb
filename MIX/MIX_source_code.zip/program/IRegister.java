//: IRegister.java
//  A two-byte 'word' used for the MIX1009 I-Registers.

/** IRegister is a two-byte word
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 January 1999
*/
class IRegister extends MIXWord
{
   /** Default constructor
    *  @return No return value.
   */
   IRegister()
   {
      super( 2 );
   }
}

///:~
