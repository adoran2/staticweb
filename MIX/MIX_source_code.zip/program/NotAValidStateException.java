//: NotAValidStateException.java
//  An Exception thrown by ComparisonIndicator

/** NotAValidStateException is an Exception thrown by ComparisonIndicator
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 March 1999
 *  @see ComparisonIndicator
*/
class NotAValidStateException extends Exception { }

///:~
