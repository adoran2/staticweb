//: IndexOutOfRangeException.java
//  An Exception thrown by MIXWord

/** IndexOutOfRangeException is an Exception thrown by MIXWord
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 March 1999
 *  @see MIXSign
*/
class IndexOutOfRangeException extends Exception { }

///:~
