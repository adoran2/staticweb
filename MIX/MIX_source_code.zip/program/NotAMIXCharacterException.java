//: NotAMIXCharacterException.java
//  An Exception thrown by LinePrinter

/** NotAMIXCharacterException is an Exception thrown by LinePrinter
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 March 1999
 *  @see LinePrinter
*/
class NotAMIXCharacterException extends Exception { }

///:~
