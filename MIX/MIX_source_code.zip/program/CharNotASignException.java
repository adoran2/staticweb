//: CharNotASignException.java
//  An Exception thrown by MIXSign

/** CharNotASignException is an Exception thrown by MIXSign
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 March 1999
 *  @see MIXSign
*/
class CharNotASignException extends Exception { }

///:~
