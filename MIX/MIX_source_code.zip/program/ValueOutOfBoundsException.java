//: ValueOutOfBoundsException.java
//  An Exception thrown by MIXByte

/** ValueOutOfBoundsException is an Exception thrown by MIXByte
 *  @author Andrew Doran
 *  @author http://andrew.doran.com/
 *  @version 0.11 - 30 March 1999
 *  @see MIXByte
*/
class ValueOutOfBoundsException extends Exception { }

///:~
